import type { Article } from "./types";
import { MOCK_ARTICLES } from "./mock-data";

const hasDatabase = Boolean(process.env.DATABASE_URL);

/**
 * `isBreaking` / `isTrending` are written once by the AI pipeline at
 * ingest time (see lib/ai.ts) and are never cleared afterwards. On a
 * quiet news day nothing new gets marked breaking, so without a
 * freshness check here the most recent article that ever *was* marked
 * breaking — even one from yesterday or last week — keeps winning
 * `getBreakingArticle()`'s `.find()` forever. That's the "yesterday's
 * news shown as today's breaking news" bug: the flag isn't stale data,
 * it's a flag with no expiry. Filtering by publish time here is a
 * read-time fix (no migration, no cron changes needed) and self-heals
 * automatically as time passes.
 */
const BREAKING_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 hours
const TRENDING_WINDOW_MS = 48 * 60 * 60 * 1000; // 48 hours

function isWithin(publishedAt: string, windowMs: number): boolean {
  return Date.now() - new Date(publishedAt).getTime() <= windowMs;
}

async function fromDb(): Promise<Article[]> {
  const { prisma } = await import("./db");
  const rows = await prisma.article.findMany({ orderBy: { publishedAt: "desc" } });
  return rows.map((r: (typeof rows)[number]) => ({
    id: r.id,
    slug: r.slug,
    headline: r.headline,
    headlineBn: r.headlineBn,
    takeaway: r.takeaway,
    takeawayBn: r.takeawayBn,
    summaryEn: r.summaryEn,
    summaryBn: r.summaryBn,
    category: r.category as Article["category"],
    source: r.source,
    sourceUrl: r.sourceUrl,
    imageUrl: r.imageUrl,
    imageCredit: r.imageCredit ?? undefined,
    publishedAt: r.publishedAt.toISOString(),
    readingTimeSeconds: r.readingTimeSeconds,
    isBreaking: r.isBreaking,
    isTrending: r.isTrending,
    tags: r.tags
  }));
}

const isProduction = process.env.NODE_ENV === "production";

/**
 * Mock-data fallback is a LOCAL-PREVIEW-ONLY convenience (see README:
 * "npm run dev" without a DATABASE_URL). It must never activate in
 * production:
 *
 *   - A production build succeeding tells you nothing about whether
 *     DATABASE_URL is set — `npm run build` only runs `prisma generate`,
 *     which reads prisma/schema.prisma and does not open a DB connection.
 *     DATABASE_URL is a *runtime* requirement, checked here on every
 *     request, not a build-time one.
 *   - Silently swapping in MOCK_ARTICLES here is exactly what produced the
 *     "site is stuck on demo content" bug: a healthy ingest pipeline
 *     writing real rows to Postgres, with the homepage never once looking
 *     at them because this function quietly returned static data instead.
 *   - Failing loudly (throwing, which surfaces as a 500 / error page) is
 *     the correct behavior in production: it's immediately visible in
 *     Vercel's function logs and in the page itself, instead of silently
 *     rendering old sample articles that keep the site LOOKING fine.
 */
export async function getArticles(): Promise<Article[]> {
  if (!hasDatabase) {
    if (isProduction) {
      throw new Error(
        "[briefly:frontend] DATABASE_URL is not set in production. Refusing to fall back to lib/mock-data.ts — " +
          "set DATABASE_URL in this Vercel project's Environment Variables (Production scope) and redeploy."
      );
    }
    console.warn("[briefly:frontend] DATABASE_URL not set — rendering from lib/mock-data.ts (local preview only)");
    return [...MOCK_ARTICLES].sort(
      (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    );
  }

  try {
    return await fromDb();
  } catch (err) {
    const message = (err as Error).message;
    if (isProduction) {
      console.error(`[briefly:frontend] DB read FAILED in getArticles() in production: ${message}`);
      throw new Error(`[briefly:frontend] Database read failed and mock-data fallback is disabled in production: ${message}`);
    }
    console.error(
      `[briefly:frontend] DB read FAILED in getArticles() — falling back to MOCK_ARTICLES (local preview only): ${message}`
    );
    return MOCK_ARTICLES;
  }
}

export async function getArticleBySlug(slug: string): Promise<Article | undefined> {
  const all = await getArticles();
  return all.find((a) => a.slug === slug);
}

export async function getArticlesByCategory(category: string): Promise<Article[]> {
  const all = await getArticles();
  return all.filter((a) => a.category === category);
}

export async function getBreakingArticle(): Promise<Article | undefined> {
  const all = await getArticles();
  return all.find((a) => a.isBreaking && isWithin(a.publishedAt, BREAKING_WINDOW_MS));
}

export async function getTrendingArticles(): Promise<Article[]> {
  const all = await getArticles();
  return all.filter((a) => a.isTrending && isWithin(a.publishedAt, TRENDING_WINDOW_MS));
}

export async function searchArticles(query: string): Promise<Article[]> {
  const all = await getArticles();
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return all.filter((a) =>
    [a.headline, a.headlineBn, a.category, a.source, ...a.tags]
      .join(" ")
      .toLowerCase()
      .includes(q)
  );
}
